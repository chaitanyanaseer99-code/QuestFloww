# Inbox Warrior — Milestone 1

A dark-fantasy RPG-style Gmail cleanup experience. This milestone delivers the responsive dashboard, interactive demo battle loop, Firebase Google sign-in foundation, and a server-side Firebase ID-token verification endpoint.

> **Important:** Demo email actions only update local React state. They do not modify Gmail. Gmail mailbox authorization and real Gmail operations are the next milestone and will use a separate server-side OAuth flow with explicit action confirmation.

## Requirements

- Node.js 20.9+ (recommended for current Next.js)
- npm
- A Firebase project for Google sign-in (optional while exploring demo mode)

## Run locally

```bash
cp .env.example .env.local
npm install
npm run dev
```

Open http://localhost:3000.

The dashboard works in demo mode without Firebase credentials. To enable Google sign-in:

1. Create a project at https://console.firebase.google.com/.
2. Add a Web App in Project settings.
3. In Authentication → Sign-in method, enable **Google**.
4. In Authentication → Settings → Authorized domains, add `localhost` for local development.
5. Copy the Firebase web app configuration into the `NEXT_PUBLIC_FIREBASE_*` values in `.env.local`.
6. For the server-side `/api/auth/verify` endpoint, create a service account and set `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, and `FIREBASE_PRIVATE_KEY`. Keep these values server-side only.
7. Restart `npm run dev`.

Google sign-in uses Firebase Authentication's `signInWithPopup`. The app's server verification endpoint accepts a Firebase ID token in the `Authorization: Bearer <token>` header.

## Available scripts

```bash
npm run dev       # local development
npm run build     # production build
npm run start     # run production build
npm run lint      # ESLint
npm run typecheck # TypeScript check
```

## Project structure

```text
src/
  app/
    api/
      auth/verify/route.ts  # verifies Firebase ID tokens server-side
      health/route.ts       # health check
    globals.css             # dark fantasy RPG design system
    layout.tsx
    page.tsx                # interactive dashboard and demo arena
  components/
    auth-provider.tsx       # Firebase Google sign-in state
  lib/
    demo/data.ts            # clearly labelled demo inbox and quests
    firebase/client.ts      # Firebase browser SDK
    firebase/admin.ts       # Firebase Admin SDK
  types/
    game.ts
firestore.rules
```

## Test the foundation

1. Open the dashboard and verify the `DEMO MODE` indicator is visible.
2. Select quests and switch between demo email cards.
3. Use Protect, Archive, and Trash. XP and quest progress should update locally.
4. Verify the demo queue can be reset after it is cleared.
5. Configure Firebase and sign in with a Google test account.
6. Open the profile menu and choose **Verify session** to test the server-side ID-token verification endpoint.
7. Check `GET /api/health` for the app health response.

## Security notes

- Do not commit `.env.local` or service-account credentials.
- Do not put Gmail refresh tokens in browser storage or public Firestore documents.
- The Firebase Admin endpoint is a verification foundation, not a complete session-cookie system.
- Gmail access will be separately authorized in the next milestone; use least-privilege Gmail scopes and keep refresh tokens encrypted on the server.
- Demo actions are not real Gmail actions.
