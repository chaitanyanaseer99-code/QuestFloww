import type { DemoEmail, Quest } from "@/types/game";

export const demoEmails: DemoEmail[] = [
  { id: "demo-1", sender: "Flash Deals", initials: "FD", subject: "Your weekend deal is waiting inside", snippet: "Up to 60% off your favorite picks. This offer ends Sunday…", time: "9:42 AM", category: "promotional", confidence: 96, action: "archive" },
  { id: "demo-2", sender: "Maya from Design", initials: "MD", subject: "Updated mockups for the launch", snippet: "Hey! I added the final screens and left two comments for your review…", time: "9:18 AM", category: "work_personal", confidence: 99, action: "keep" },
  { id: "demo-3", sender: "Daily Crypto Digest", initials: "CD", subject: "Your Tuesday market roundup", snippet: "Here are the five stories everyone is talking about today…", time: "8:56 AM", category: "newsletter", confidence: 91, action: "archive" },
  { id: "demo-4", sender: "Prize Center", initials: "PC", subject: "Congratulations! Claim your reward now", snippet: "You have been selected. Verify your details to claim your prize…", time: "Yesterday", category: "spam", confidence: 88, action: "trash" },
  { id: "demo-5", sender: "Google Calendar", initials: "GC", subject: "Reminder: Product review at 2:00 PM", snippet: "Your event starts in 30 minutes. Open the event to see details…", time: "Yesterday", category: "important", confidence: 98, action: "keep" },
];

export const initialQuests: Quest[] = [
  { id: "q1", title: "The Promotion Goblin", subtitle: "Clear 12 promotional scrolls", category: "promotional", progress: 7, total: 12, xp: 120, icon: "🧌", tone: "violet" },
  { id: "q2", title: "Slay the Spam Slime", subtitle: "Review 8 suspicious messages", category: "spam", progress: 3, total: 8, xp: 160, icon: "🟢", tone: "cyan" },
  { id: "q3", title: "Rescue the Treasures", subtitle: "Protect 5 important emails", category: "important", progress: 2, total: 5, xp: 100, icon: "💎", tone: "amber" },
];
