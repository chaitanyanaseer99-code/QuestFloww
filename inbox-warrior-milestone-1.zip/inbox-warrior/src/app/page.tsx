"use client";

import { useMemo, useState } from "react";
import type { ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Activity, Archive, ArrowRight, ArrowUpRight, Bell,
  CheckCircle2, ChevronDown, Crown, Flame, Gem, Inbox, LockKeyhole,
  LogOut, Mail, Menu, MoreHorizontal, Plus, RefreshCw, Settings, Shield,
  ShieldAlert, Sparkles, Swords, Target, Trash2, Trophy, WandSparkles, X, Zap,
} from "lucide-react";
import { useAuth } from "@/components/auth-provider";
import { demoEmails, initialQuests } from "@/lib/demo/data";
import type { DemoEmail, GameAction, Quest } from "@/types/game";

const categoryLabel: Record<DemoEmail["category"], string> = {
  spam: "Possible spam", promotional: "Promotional", newsletter: "Newsletter",
  important: "Important", social: "Social", work_personal: "Work & personal",
};

export default function Home() {
  const { user, loading, configured, signIn, signOutUser } = useAuth();
  const [emails, setEmails] = useState(demoEmails);
  const [quests, setQuests] = useState(initialQuests);
  const [activeQuest, setActiveQuest] = useState("q1");
  const [selectedEmail, setSelectedEmail] = useState(demoEmails[0].id);
  const [xp, setXp] = useState(420);
  const [toast, setToast] = useState("");
  const [showProfile, setShowProfile] = useState(false);
  const [showAllEmails, setShowAllEmails] = useState(false);
  const [busy, setBusy] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);

  const currentEmail = emails.find((email) => email.id === selectedEmail) ?? emails[0];
  const currentQuest = quests.find((quest) => quest.id === activeQuest) ?? quests[0];
  const level = Math.floor(xp / 200) + 1;
  const levelProgress = (xp % 200) / 200 * 100;
  const remaining = emails.length;
  const processed = 180 + (demoEmails.length - emails.length);
  const visibleEmails = showAllEmails ? emails : emails.slice(0, 4);
  const categoryCounts = useMemo(() => ({
    spam: emails.filter((email) => email.category === "spam").length,
    promotional: emails.filter((email) => email.category === "promotional").length,
    important: emails.filter((email) => email.category === "important").length,
  }), [emails]);

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2800);
  }

  async function handleSignIn() {
    try {
      await signIn();
      notify("Google sign-in successful. Gmail access is a separate step.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Sign-in failed. Check Firebase configuration.");
    }
  }

  async function handleVerifySession() {
    if (!user) return;
    setBusy(true);
    try {
      const token = await user.getIdToken();
      const response = await fetch("/api/auth/verify", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });
      const result = await response.json();
      notify(result.ok ? `Verified securely as ${result.email ?? result.uid}` : result.error);
    } catch {
      notify("Could not verify session. Check server configuration.");
    } finally {
      setBusy(false);
    }
  }

  function performDemoAction(action: GameAction) {
    if (!currentEmail) return;
    const label = action === "keep" ? "protected" : action === "archive" ? "archived" : "moved to Trash";
    setEmails((previous) => previous.filter((email) => email.id !== currentEmail.id));
    const earned = action === "keep" ? 15 : action === "archive" ? 20 : 30;
    setXp((previous) => previous + earned);
    setQuests((previous) => previous.map((quest) => quest.category === currentEmail.category
      ? { ...quest, progress: Math.min(quest.total, quest.progress + 1) }
      : quest));
    const next = emails.find((email) => email.id !== currentEmail.id);
    setSelectedEmail(next?.id ?? "");
    notify(`Demo action: email ${label}. +${earned} XP earned.`);
  }

  function startQuest(quest: Quest) {
    setActiveQuest(quest.id);
    const next = emails.find((email) => email.category === quest.category);
    if (next) setSelectedEmail(next.id);
    notify(`${quest.title} quest selected`);
  }

  return (
    <main className="app-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand-lockup">
          <div className="brand-mark"><Swords size={21} strokeWidth={2.3} /></div>
          <div><div className="brand-name">INBOX<span>WARRIOR</span></div><div className="brand-caption">THE EMAIL RPG</div></div>
          <button className="icon-button mobile-close" onClick={() => setMobileNav(false)} aria-label="Close menu"><X size={18}/></button>
        </div>
        <div className="season-card">
          <div className="season-top"><span className="season-dot"/> SEASON 01 <span className="season-live">LIVE</span></div>
          <div className="season-title">The Great<br/><span>Inbox Purge</span></div>
          <div className="season-bottom"><span>SEASON ENDS IN</span><strong>12D : 08H</strong></div>
        </div>
        <div className="nav-label">WORKSPACE</div>
        <nav className="side-nav">
          <a className="nav-item active" href="#dashboard"><Inbox size={17}/> <span>Command Center</span><span className="nav-indicator"/></a>
          <a className="nav-item" href="#quests"><Target size={17}/> <span>Quest Board</span><span className="nav-count">3</span></a>
          <a className="nav-item" href="#arena"><Swords size={17}/> <span>Battle Arena</span></a>
          <a className="nav-item" href="#achievements"><Trophy size={17}/> <span>Achievements</span></a>
        </nav>
        <div className="nav-label nav-label-spaced">YOUR MAILBOX</div>
        <div className="mailbox-mini">
          <div className="mailbox-row"><span className="mailbox-icon violet"><Mail size={15}/></span><span>Promotions</span><strong>{categoryCounts.promotional}</strong></div>
          <div className="mailbox-row"><span className="mailbox-icon cyan"><ShieldAlert size={15}/></span><span>Suspicious</span><strong>{categoryCounts.spam}</strong></div>
          <div className="mailbox-row"><span className="mailbox-icon amber"><Gem size={15}/></span><span>Important</span><strong>{categoryCounts.important}</strong></div>
        </div>
        <div className="sidebar-bottom">
          <div className="wiz-tip"><div className="wiz-avatar"><WandSparkles size={17}/></div><div><strong>Wiz says...</strong><p>Every inbox has a hero. Today, it's you.</p></div></div>
          <button className="nav-item settings-link" onClick={() => notify("Settings will arrive in the next milestone.")}><Settings size={17}/><span>Settings</span></button>
          <div className="sidebar-footer"><span className="footer-orb"/> BUILT FOR THE BRAVE <span>v0.1.0</span></div>
        </div>
      </aside>

      <section className="main-panel" id="dashboard">
        <header className="topbar">
          <div className="topbar-left"><button className="icon-button mobile-menu" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu size={20}/></button><div className="breadcrumb">WORKSPACE <span>/</span> <strong>COMMAND CENTER</strong></div></div>
          <div className="topbar-right">
            {!user && <button className="secondary-button top-sign-in" onClick={handleSignIn} disabled={loading}><LockKeyhole size={14}/>{loading ? "Loading…" : "Sign in"}</button>}
            <div className="demo-pill"><span/> DEMO MODE</div>
            <button className="icon-button notification-button" aria-label="Notifications" onClick={() => notify("You're all caught up, warrior.")}><Bell size={18}/><i/></button>
            <div className="profile-wrap">
              <button className="profile-button" onClick={() => setShowProfile(!showProfile)}>
                <div className="profile-avatar">{user?.photoURL ? <img src={user.photoURL} alt="Profile"/> : "W"}</div>
                <div className="profile-meta"><strong>{user?.displayName?.split(" ")[0] ?? "Warrior"}</strong><span>LEVEL {level}</span></div><ChevronDown size={14}/>
              </button>
              {showProfile && <div className="profile-menu">{user ? <><div className="profile-menu-email">{user.email}</div><button onClick={handleVerifySession} disabled={busy}><Shield size={15}/> {busy ? "Verifying…" : "Verify session"}</button><button onClick={() => signOutUser()}><LogOut size={15}/> Sign out</button></> : <><div className="profile-menu-email">Guest warrior</div><button onClick={handleSignIn}><LockKeyhole size={15}/> Sign in with Google</button></>}</div>}
            </div>
          </div>
        </header>

        <div className="content-wrap">
          <section className="welcome-row">
            <div><div className="eyebrow"><Sparkles size={14}/> YOUR ADVENTURE CONTINUES</div><h1>Good day, <span>{user?.displayName?.split(" ")[0] ?? "Warrior"}.</span></h1><p>Your inbox won't clean itself. Ready to make some progress?</p></div>
            <div className="welcome-actions"><button className="secondary-button" onClick={() => notify("Demo inbox refreshed.")}><RefreshCw size={15}/> Refresh scan</button><button className="primary-button" onClick={() => notify("Gmail OAuth is the next milestone. No real mailbox changes happen in demo mode.")}><Plus size={16}/> Connect Gmail</button></div>
          </section>

          {!configured && <div className="setup-banner"><div className="setup-icon"><LockKeyhole size={18}/></div><div><strong>Firebase setup needed for Google sign-in</strong><p>Add your Firebase web config to <code>.env.local</code>. You can explore the playable demo in the meantime.</p></div><a href="#setup">Setup guide <ArrowRight size={14}/></a></div>}

          <section className="hero-grid">
            <div className="hero-card">
              <div className="hero-noise"/><div className="hero-content"><div className="hero-kicker"><span className="live-pulse"/> ACTIVE CAMPAIGN <span className="hero-separator">/</span> CHAPTER 01</div><h2>The Great<br/><em>Inbox Purge</em></h2><p>A thousand distractions. One brave warrior.<br/>Let's reclaim your digital kingdom.</p><div className="hero-buttons"><button className="hero-cta" onClick={() => document.getElementById("arena")?.scrollIntoView({ behavior: "smooth" })}>Enter the arena <ArrowRight size={16}/></button><span className="hero-chapter"><Crown size={14}/> CHAPTER I OF V</span></div></div><div className="hero-art"><div className="hero-rune rune-one">✧</div><div className="hero-rune rune-two">✦</div><div className="hero-ring ring-back"/><div className="hero-ring ring-front"/><div className="hero-sigil"><Swords size={80} strokeWidth={1.1}/></div><div className="hero-crystal crystal-a"/><div className="hero-crystal crystal-b"/><div className="hero-art-label">THE INBOX<br/>AWAKENS</div></div><div className="hero-bottom-line"/></div>
            <div className="level-card"><div className="level-card-top"><span>WARRIOR PROFILE</span><MoreHorizontal size={18}/></div><div className="warrior-row"><div className="warrior-emblem"><Shield size={33}/><span>{level}</span></div><div><div className="warrior-name">Inbox Warrior</div><div className="warrior-rank">{level < 2 ? "Inbox Initiate" : level < 4 ? "Email Hunter" : "Inbox Guardian"}</div></div></div><div className="xp-row"><span>EXPERIENCE</span><strong>{xp.toLocaleString()} <small>/ {(Math.floor(xp / 200) + 1) * 200} XP</small></strong></div><div className="xp-track"><div style={{ width: `${levelProgress}%` }}/></div><div className="xp-footer"><span>LEVEL {level}</span><span>{Math.max(0, 200 - xp % 200)} XP TO NEXT LEVEL</span></div><div className="level-divider"/><div className="level-stats"><div><strong>{processed}</strong><span>QUEST ACTIONS</span></div><div><strong>{quests.filter(q => q.progress >= q.total).length}</strong><span>QUESTS CLEARED</span></div><div><strong>🔥 4</strong><span>DAY STREAK</span></div></div></div>
          </section>

          <section className="stats-grid">
            <StatCard icon={<Inbox size={17}/>} label="MESSAGES IN QUEUE" value={String(remaining).padStart(2,"0")} detail="Demo messages" tone="violet" trend="Ready to review"/>
            <StatCard icon={<Archive size={17}/>} label="EMAILS ORGANIZED" value="180" detail="Across all missions" tone="cyan" trend="+12% this week"/>
            <StatCard icon={<Zap size={17}/>} label="TOTAL XP EARNED" value={xp.toLocaleString()} detail="Lifetime experience" tone="amber" trend="Keep going"/>
            <StatCard icon={<Activity size={17}/>} label="INBOX HEALTH" value="72%" detail="Your kingdom's status" tone="green" trend="Looking good"/>
          </section>

          <section className="section-block" id="quests"><div className="section-heading"><div><div className="eyebrow">CHOOSE YOUR CHALLENGE</div><h3>Active <span>quests</span></h3></div><button className="text-link" onClick={() => notify("All quests are shown on this board in the first milestone.")}>QUEST BOARD <ArrowRight size={14}/></button></div><div className="quest-grid">{quests.map((quest) => <QuestCard key={quest.id} quest={quest} active={quest.id === activeQuest} onClick={() => startQuest(quest)}/>)}</div></section>

          <section className="arena-section" id="arena"><div className="section-heading"><div><div className="eyebrow"><Swords size={13}/> LIVE ENCOUNTER</div><h3>Battle <span>arena</span></h3></div><div className="arena-tag"><span/> ENCOUNTER IN PROGRESS</div></div><div className="arena-grid"><div className="battle-card"><div className="battle-top"><div><span className="boss-label">CURRENT OPPONENT</span><h4>{currentQuest?.title ?? "The Inbox Beast"}</h4><p>{currentQuest?.subtitle ?? "Choose a quest to begin"}</p></div><div className="boss-level">BOSS <strong>LV. 04</strong></div></div><div className="boss-stage"><div className="stage-stars">✦　·　✧　·　✦　·　✧</div><div className="boss-orbit orbit-one"/><div className="boss-orbit orbit-two"/><motion.div key={currentQuest?.id} initial={{ y: 8, scale: .92 }} animate={{ y: [0,-7,0], scale: 1 }} transition={{ y: { duration: 3, repeat: Infinity, ease: "easeInOut" }, scale: { duration: .4 } }} className="boss-character">{currentQuest?.icon ?? "👾"}</motion.div><div className="boss-stage-name">{currentQuest?.title?.toUpperCase()}</div><div className="boss-stage-sub">A DIGITAL MENACE HAS APPEARED</div></div><div className="boss-health"><div className="health-label"><span><Activity size={13}/> BOSS VITALITY</span><strong>{Math.max(0, Math.round((1 - (currentQuest?.progress ?? 0) / (currentQuest?.total ?? 1)) * 100))}%</strong></div><div className="health-track"><div style={{ width: `${Math.max(0, (1 - (currentQuest?.progress ?? 0) / (currentQuest?.total ?? 1)) * 100)}%` }}/></div><div className="health-foot"><span>QUEST PROGRESS</span><span>{currentQuest?.progress ?? 0} / {currentQuest?.total ?? 0} EMAILS</span></div></div></div>
              <div className="email-panel"><div className="email-panel-top"><div><span className="boss-label">INCOMING TARGET</span><h4>Choose your move</h4></div><span className="queue-count">{emails.length} IN QUEUE</span></div>{currentEmail ? <AnimatePresence mode="wait"><motion.div key={currentEmail.id} initial={{ opacity: 0, x: 14 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -14 }} className="email-card"><div className="email-card-head"><div className="sender-avatar">{currentEmail.initials}</div><div className="sender-meta"><strong>{currentEmail.sender}</strong><span>{currentEmail.time}</span></div><button className="icon-button small" onClick={() => notify("Email details will be available after Gmail connection.")}><MoreHorizontal size={17}/></button></div><div className="email-category"><span className={`category-dot ${currentEmail.category}`}/>{categoryLabel[currentEmail.category]} <span className="confidence">AI MATCH {currentEmail.confidence}%</span></div><h5>{currentEmail.subject}</h5><p>{currentEmail.snippet}</p><div className="email-actions"><button className="email-action keep" onClick={() => performDemoAction("keep")}><Shield size={15}/> Protect</button><button className="email-action archive" onClick={() => performDemoAction("archive")}><Archive size={15}/> Archive</button><button className="email-action trash" onClick={() => performDemoAction("trash")}><Trash2 size={15}/> Trash</button></div><div className="demo-disclaimer">DEMO INTERACTION · NO GMAIL CHANGES ARE MADE</div></motion.div></AnimatePresence> : <div className="empty-state"><CheckCircle2 size={30}/><strong>Queue cleared!</strong><span>You've reviewed every demo email. A true inbox awaits.</span><button className="secondary-button" onClick={() => { setEmails(demoEmails); setSelectedEmail(demoEmails[0].id); }}>Reset demo queue</button></div>}<div className="email-panel-foot"><span><LockKeyhole size={12}/> Actions require your approval</span><button onClick={() => setShowAllEmails(!showAllEmails)}>{showAllEmails ? "SHOW LESS" : "VIEW QUEUE"} <ArrowRight size={12}/></button></div>{showAllEmails && <div className="queue-list">{visibleEmails.map(email => <button key={email.id} onClick={() => setSelectedEmail(email.id)} className={email.id === currentEmail?.id ? "queue-row selected" : "queue-row"}><span className="queue-avatar">{email.initials}</span><span className="queue-copy"><strong>{email.sender}</strong><small>{email.subject}</small></span><span className={`category-dot ${email.category}`}/></button>)}</div>}</div></div></section>

          <section className="bottom-grid" id="achievements"><div className="achievement-card"><div className="section-heading compact"><div><div className="eyebrow">YOUR TROPHY ROOM</div><h3>Recent <span>achievements</span></h3></div><Trophy size={19}/></div><div className="achievement-row"><div className="achievement-icon gold"><Crown size={20}/></div><div><strong>First Blood</strong><span>Complete your first email action</span></div><span className="achievement-status">UNLOCKED</span></div><div className="achievement-row"><div className="achievement-icon violet"><Flame size={20}/></div><div><strong>On a Roll</strong><span>Maintain a 3-day streak</span></div><span className="achievement-status">UNLOCKED</span></div><div className="achievement-row muted"><div className="achievement-icon cyan"><Gem size={20}/></div><div><strong>Inbox Alchemist</strong><span>Organize 100 emails</span></div><span className="achievement-status locked">LOCKED</span></div></div><div className="activity-card"><div className="section-heading compact"><div><div className="eyebrow">THE BATTLE LOG</div><h3>Recent <span>activity</span></h3></div><Activity size={19}/></div><div className="activity-row"><div className="activity-icon violet"><Archive size={15}/></div><div><strong>Promotional scroll archived</strong><span>Promotion Goblin · Just now</span></div><span className="activity-xp">+20 XP</span></div><div className="activity-row"><div className="activity-icon cyan"><Shield size={15}/></div><div><strong>Important email protected</strong><span>Treasure Rescue · 2h ago</span></div><span className="activity-xp">+15 XP</span></div><div className="activity-row"><div className="activity-icon amber"><Zap size={15}/></div><div><strong>Daily quest refreshed</strong><span>Wiz · Yesterday</span><span className="activity-xp">NEW</span></div></div></div></section>

          <footer className="main-footer"><span>© 2026 INBOX WARRIOR</span><span><Shield size={12}/> YOUR INBOX. YOUR RULES. YOUR ADVENTURE.</span><a href="#setup">SETUP & DOCS <ArrowUpRight size={12}/></a></footer>
        </div>
      </section>
      <AnimatePresence>{toast && <motion.div className="toast" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }}><CheckCircle2 size={17}/>{toast}</motion.div>}</AnimatePresence>
      <section id="setup" className="sr-only"><h2>Setup instructions</h2><p>Configure Firebase environment variables to enable Google sign in.</p></section>
    </main>
  );
}

function StatCard({ icon, label, value, detail, tone, trend }: { icon: ReactNode; label: string; value: string; detail: string; tone: string; trend: string }) {
  return <div className="stat-card"><div className="stat-top"><span className={`stat-icon ${tone}`}>{icon}</span><span className="stat-trend">{trend}</span></div><div className="stat-value">{value}</div><div className="stat-label">{label}</div><div className="stat-detail">{detail}</div></div>;
}

function QuestCard({ quest, active, onClick }: { quest: Quest; active: boolean; onClick: () => void }) {
  const percent = Math.min(100, quest.progress / quest.total * 100);
  return <button className={`quest-card ${active ? "quest-active" : ""}`} onClick={onClick}><div className="quest-card-top"><div className={`quest-icon ${quest.tone}`}>{quest.icon}</div><span className="quest-reward"><Zap size={12}/>{quest.xp} XP</span></div><div className="quest-title">{quest.title}</div><div className="quest-subtitle">{quest.subtitle}</div><div className="quest-progress-head"><span>PROGRESS</span><strong>{quest.progress}/{quest.total}</strong></div><div className="quest-progress"><div className={quest.tone} style={{ width: `${percent}%` }}/></div><div className="quest-card-bottom"><span>{Math.round(percent)}% COMPLETE</span><span>{active ? "ACTIVE QUEST" : "VIEW QUEST"} <ArrowRight size={12}/></span></div></button>;
}
