export async function GET() {
  return Response.json({
    ok: true,
    app: "inbox-warrior",
    milestone: "foundation",
    timestamp: new Date().toISOString(),
  });
}
