import { getFirebaseAdminAuth } from "@/lib/firebase/admin";

export async function POST(request: Request) {
  const authHeader = request.headers.get("authorization");
  const idToken = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!idToken) return Response.json({ error: "Missing Firebase ID token" }, { status: 401 });

  const adminAuth = getFirebaseAdminAuth();
  if (!adminAuth) return Response.json({ error: "Firebase Admin is not configured on the server" }, { status: 503 });

  try {
    const decoded = await adminAuth.verifyIdToken(idToken, true);
    return Response.json({ ok: true, uid: decoded.uid, email: decoded.email ?? null });
  } catch {
    return Response.json({ error: "Invalid or expired Firebase ID token" }, { status: 401 });
  }
}
