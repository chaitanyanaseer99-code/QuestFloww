export type EmailCategory = "spam" | "promotional" | "newsletter" | "important" | "social" | "work_personal";
export type GameAction = "keep" | "archive" | "trash";

export type DemoEmail = {
  id: string;
  sender: string;
  initials: string;
  subject: string;
  snippet: string;
  time: string;
  category: EmailCategory;
  confidence: number;
  action: GameAction;
};

export type Quest = {
  id: string;
  title: string;
  subtitle: string;
  category: EmailCategory;
  progress: number;
  total: number;
  xp: number;
  icon: string;
  tone: "violet" | "cyan" | "amber";
};
